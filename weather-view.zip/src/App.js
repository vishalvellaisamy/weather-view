import React, { useState } from "react";
import SearchBar from "./components/SearchBar";
import WeatherInfo from "./components/WeatherInfo";
import "./App.css";

const App = () => {
  const [city, setCity] = useState("");
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState(null);

  const fetchWeather = async (city) => {
    try {
      const response = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=2d9cbc658aa44b90b01142101242710&q=${city}`
      );
      const data = await response.json();
      if (data.error) {
        setError("City not found");
        setWeatherData(null);
      } else {
        setWeatherData(data);
        setError(null);
      }
    } catch (err) {
      setError("Error fetching weather data");
      setWeatherData(null);
    }
  };

  const handleSearch = (city) => {
    setCity(city);
    fetchWeather(city);
  };

  return (
    <div className="app">
      <h1>Weather Dashboard</h1>
      <SearchBar onSearch={handleSearch} />
      {error ? <p className="error">{error}</p> : <WeatherInfo data={weatherData} />}
    </div>
  );
};

export default App;
