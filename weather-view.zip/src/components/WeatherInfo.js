import React from "react";

const WeatherInfo = ({ data }) => {
  if (!data) return null;

  const { location, current } = data;

  return (
    <div className="weather-info">
      <h2>{location.name}, {location.country}</h2>
      <p>{current.condition.text}</p>
      <p>Temperature: {current.temp_c} °C</p>
      <p>Humidity: {current.humidity} %</p>
      <p>Wind Speed: {current.wind_kph} kph</p>
    </div>
  );
};

export default WeatherInfo;
